/** Program by Soeren Walls */

public class Controller {
	@SuppressWarnings("unused")
	public static void main(String[] args)
	{
		//Instantiate new GUI to display game instructions
		InstructionsGUI instructions = new InstructionsGUI();
	}
}